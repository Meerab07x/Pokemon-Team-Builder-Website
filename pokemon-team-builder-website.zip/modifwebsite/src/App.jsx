import { useState, useEffect } from 'react'
import Login from './components/Login'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import TeamBuilder from './components/TeamBuilder'
import Contact from './pages/Contact'
import Privacy from './pages/Privacy'
import CookiesPage from './pages/Cookies'

export default function App(){
  const [user, setUser] = useState(null)
  const [route, setRoute] = useState('home') // home, contact, privacy, cookies, login
  const [showCookieModal, setShowCookieModal] = useState(false)
  const [cookiesAccepted, setCookiesAccepted] = useState(null) // null = not decided, true = accepted, false = declined

  // Show cookie modal after successful login
  useEffect(() => {
    if (user && cookiesAccepted === null) {
      setShowCookieModal(true)
    }
  }, [user, cookiesAccepted])

  // Handle routing based on user state
  useEffect(()=>{
    if(!user){
      setRoute('login')
    } else if(route === 'login') {
      setRoute('home')
    }
  },[user])

  function handleLogin(u){
    setUser(u)
    setRoute('home')
  }

  function handleRoute(r){
    setRoute(r)
  }

  function handleLogout(){
    setUser(null)
    setRoute('login')
    setCookiesAccepted(null)
    setShowCookieModal(false)
  }

  function acceptCookies(){
    setCookiesAccepted(true)
    setShowCookieModal(false)
  }

  function declineCookies(){
    setCookiesAccepted(false)
    setShowCookieModal(false)
  }

  return (
    <div>
      <div className='container'>
        <header className='nav'> 
          <div className='logo'>Your Pokémon Team Builder</div>

          <nav className='links'>
            {user && <a className='muted' onClick={()=>handleRoute('home')}>Home</a>}
            <a className='muted' onClick={()=>{handleRoute('contact')}}>Contact</a>
            <a className='muted' onClick={()=>{handleRoute('privacy')}}>Privacy Policy</a>
            {!user ? null : <a className='cta btn' onClick={handleLogout} style={{marginLeft:8}}>Logout</a>}
          </nav>
        </header>

        <main>
          {!user && route === 'login' &&
            <Login onLogin={handleLogin} onRoute={handleRoute} />
          }
          {user && route === 'home' &&
            <TeamBuilder user={user} />
          }
          {route === 'contact' && <Contact onReturn={()=>setRoute(user? 'home':'login')} />}
          {route === 'privacy' && <Privacy onReturn={()=>setRoute(user? 'home':'login')} />}
          {route === 'cookies' && <CookiesPage onReturn={()=>setRoute('login')} />}
        </main>

        <Footer />
      </div>

      {showCookieModal && (
        <>
          <div 
            className='cookie-modal-backdrop'
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: 'rgba(0,0,0,0.4)',
              zIndex: 99
            }}
          />
          <div className='cookie-modal card'>
            <h3>🍪 We use Cookies</h3>
            <p className='muted'>
              This site uses cookies to improve your experience and remember your preferences. 
              You can accept or decline. For more details, see our{' '}
              <a className='link' onClick={(e)=>{ e.stopPropagation(); setRoute('cookies'); }}>
                Cookie Policy
              </a>.
            </p>
            <div style={{display:'flex',gap:10,justifyContent:'flex-end',marginTop:20}}>
              <button className='btn btn-ghost' onClick={declineCookies}>Decline</button>
              <button className='btn btn-primary' onClick={acceptCookies}>Accept</button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}