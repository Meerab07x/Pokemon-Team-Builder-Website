import { useState, useEffect } from 'react'
import Login from './components/Login'
import Footer from './components/Footer'
import TeamBuilder from './components/TeamBuilder'
import Contact from './pages/Contact'
import Privacy from './pages/Privacy'
import CookiesPage from './pages/Cookies'

export default function App() {
  const [user, setUser] = useState(null)
  const [route, setRoute] = useState('home') // home, contact, privacy, cookies, login
  const [showCookieModal, setShowCookieModal] = useState(false)
  const [cookiesAccepted, setCookiesAccepted] = useState(null) // null = not decided, true = accepted, false = declined

  // shows cookie modal after successful login
  useEffect(() => {
    if (user && cookiesAccepted === null) {
      setShowCookieModal(true)
    }
  }, [user, cookiesAccepted])

  // handles routing based on user state
  useEffect(() => {
    if (!user) {
      setRoute('login')
    } else if (route === 'login') {
      setRoute('home')
    }
  }, [user])

  function handleLogin(u) {
    setUser(u)
    setRoute('home')
  }

  function handleLogout() {
    setUser(null)
    setRoute('login')
    setCookiesAccepted(null)
    setShowCookieModal(false)
  }

  function handleRoute(r) {
    setRoute(r)
  }

  function acceptCookies() {
    setCookiesAccepted(true)
    setShowCookieModal(false)
  }

  function declineCookies() {
    setCookiesAccepted(false)
    setShowCookieModal(false)
  }

  return (
    <div>
      <div className="container">
        {/* --- NAVBAR --- */}
        <header className="nav">
          <div className="logo">Your Pokémon Team Builder</div>

          <nav className="links">
            {user && (
              <a onClick={() => handleRoute('home')}>
                Home
              </a>
            )}
            <a onClick={() => handleRoute('contact')}>
              Contact
            </a>
            <a onClick={() => handleRoute('privacy')}>
              Privacy Policy
            </a>
            {user && (
              <button
                className="btn btn-primary"
                onClick={handleLogout}
              >
                Logout
              </button>
            )}
          </nav>
        </header>

        <main>
          {/* Login Page */}
          {!user && route === 'login' && (
            <Login onLogin={handleLogin} onRoute={handleRoute} />
          )}

          {/* Home Page */}
          {user && route === 'home' && <TeamBuilder user={user} />}

          {/* Contact Page */}
          {route === 'contact' && (
            <Contact onReturn={() => setRoute(user ? 'home' : 'login')} />
          )}

          {/* Privacy Policy Page */}
          {route === 'privacy' && (
            <Privacy onReturn={() => setRoute(user ? 'home' : 'login')} />
          )}

          {/* Cookies Policy Page */}
          {route === 'cookies' && (
            <CookiesPage onReturn={() => setRoute('login')} />
          )}
        </main>

        {/* --- FOOTER --- */}
        <Footer />
      </div>

      {/* --- COOKIE MODAL --- */}
      {showCookieModal && (
        <>
          <div
            className="cookie-modal-backdrop"
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: 'rgba(0,0,0,0.4)',
              zIndex: 99,
            }}
          />
          <div
            className="cookie-modal card"
            style={{
              position: 'fixed',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              zIndex: 100,
              background: 'white',
              padding: 20,
              borderRadius: 12,
              width: '90%',
              maxWidth: 400,
              boxShadow: '0 8px 20px rgba(0,0,0,0.2)',
            }}
          >
            <h3>We use Cookies</h3>
            <p className="muted">
              This site uses cookies to improve your experience and remember your
              preferences. You can accept or decline. For more details, see our{' '}
              <button
                className="link"
                style={{ border: 'none', background: 'transparent', padding: 0 }}
                onClick={(e) => {
                  e.stopPropagation()
                  setShowCookieModal(false)
                  setRoute('cookies')
                }}
              >
                Cookie Policy
              </button>
              .
            </p>
            <div
              style={{
                display: 'flex',
                gap: 10,
                justifyContent: 'flex-end',
                marginTop: 20,
              }}
            >
              <button className="btn btn-ghost" onClick={declineCookies}>
                Decline
              </button>
              <button className="btn btn-primary" onClick={acceptCookies}>
                Accept
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}